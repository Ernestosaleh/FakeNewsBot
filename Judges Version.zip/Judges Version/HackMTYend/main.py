#uvicorn main:app --reload
from fastapi import FastAPI
import joblib
import re
import pandas as pd
import numpy as np

import tensorflow as tf
import tensorflow_hub as hub
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer

from modelUtils import *

embed = hub.load("https://tfhub.dev/google/Wiki-words-250/2")

# vectorizer=joblib.load("model1.joblib")
# transformer=joblib.load("transformer.joblib")
# SVC=joblib.load("svc.joblib")
new_model = tf.keras.models.load_model('model1.h5')


app = FastAPI()

input="covid doesn't exist"
@app.get("/prediccion/{tweet_string}")
async def prediccion(tweet_string):

    # if type(tweet_string)!=type(["uwu"]):
    #     tweet_string=[tweet_string]

    F1=lambda x:re.sub('@[^\s]+','',x)#Remove twitter handlers
    F2=lambda x:' '.join(re.findall(r'\w+', x))# Remove all the special characters
    F3=lambda x:re.sub(r'\s+[a-zA-Z]\s+', ' ', x)#remove all single characters
    F4=lambda x:re.sub(r'\s+', ' ', x, flags=re.I) # Substituting multiple spaces with single space

    # Fstring=[F4(F3(F2(F1(x)))).lower() for x in tweet_string]
    print(type(tweet_string))
    print(tweet_string)
    Fstring=np.array([F4(F3(F2(F1(tweet_string)))).lower()])
    # print("1: "+str(Fstring))
    # Fstring=vectorizer.transform(Fstring)
    # print("2: "+str(Fstring))
    # Fstring=transformer.transform(Fstring)
    # print("3: "+str(Fstring))
    # Fstring=SVC.predict(Fstring)
    # print("4: "+str(Fstring))


    Fstring = get_word2vec_enc(Fstring, embed)
    Fstring = get_padded_encoded_reviews(Fstring,290)
    Fstring = np.array(Fstring)
    Result=new_model.predict(Fstring)
    Result=Result[0][0]

    return {"tweet_string": str(Result)}

big_str="alexandria ocasio cortez tweeted it vital that governors maintain restrictions on businesses until after the november elections because economic recovery will help trump be re elected few business closures or job losses is small price to pay to be free from his presidency keepusclosed"
big_str2="""India has reported 43 COVID-19 cases in 9 states and UTs so far. Here is an in-depth guide to #coronavirus cases in India.  \n(@mukeshrawat705)\n\n https://www.indiatoday.in/india/story/coronavirus-cases-in-india-covid19-states-cities-affected-1653852-2020-03-09/xa0"""
big_str3="the indian embassy in tokyo has said that one more indian crew member on diamond princess has tested positive for covid 19 https www indiatoday in india story third indian aboard japanese ship tests positive for coronavirus 1646514 2020 02 14"

#print(prediccion([big_str3]))



