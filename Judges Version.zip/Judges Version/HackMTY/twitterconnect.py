import tweepy
import datetime
import json
import requests
import logging
from azure.storage.blob import BlockBlobService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()


def getfromAPI(tweet_string):
    response=requests.get("http://127.0.0.1:8000/prediccion/"+tweet_string)
    data=json.loads(response.text)
    x=float(data["tweet_string"])
    if x>=0.5:
        y=1
    elif x<0.5:
        y=0
    return(y)

#Add own keys
consumer_apikey=""
consumer_secretkey=""
access_apikey=""
access_secretkey=""

auth=tweepy.OAuthHandler(consumer_apikey, consumer_secretkey)
auth.set_access_token(access_apikey, access_secretkey)
api=tweepy.API(auth)

#Twitter bot username
my_screen_name=""
def check_mentions(api, since_id):
    tweets=dict()
    logger.info("Retrieving mentions")
    new_since_id=since_id
    for substatus in tweepy.Cursor(api.mentions_timeline, since_id=since_id).items():
        try:
            if substatus.in_reply_to_status_id == None: #True si no es un reply
                continue
            followers=[follower.screen_name for follower in api.followers()]
            print(followers)
            followers.append(my_screen_name) #My own screen_name
            user_screen_name=substatus.user.screen_name
            #if user_screen_name not in followers: #El usuario no me sigue
                #continue
            # try:
            ID=substatus.in_reply_to_status_id
            status=api.get_status(ID, tweet_mode="extended")
            lead_user_screen_name=status.user.screen_name
            if lead_user_screen_name==my_screen_name: #No me puede contestar a mi mismo a menos que yo lo pida
                if user_screen_name!=my_screen_name:
                    continue
            new_since_id = max(substatus.id, new_since_id)
            tweet=_gettweetfulltext(status)
            if "@"+my_screen_name in tweet: #No contesta tweets que respondan a mi etiqueta
                continue
            tweets[substatus.id]=(tweet, user_screen_name)

            logger.info(f"Answering to {substatus.user.name}")
            # except Exception as e:
            #     logging.error(e)
            logger.info(f"{tweets}")
        except Exception:
            logging.exception("message")
            try:
                user_screen_name=substatus.user.screen_name
                tweets[substatus.id]=(None, user_screen_name) #El None provocara un error en el siguiente segmento
            except Exception:
                logging.exception("message")

    return(tweets, new_since_id)


def mention_reply(tweets):
    for ID in tweets.keys():
        #filename="perroto.jpg"
        try:
            x=getfromAPI(tweets[ID][0])
            if x==1:
                filename="yes.jpg"
            else:
                filename="no.jpg"
            logger.info(f"{type(tweets[ID][0])}")
            #El tweet no es mi arroba.
            if str(tweets[ID][1])!=my_screen_name:
                replyto="@"+str(tweets[ID][1])
            else:
                replyto=""
            kwargs={"status":replyto ,"in_reply_to_status_id":ID}
            api.update_with_media(filename=filename,  **kwargs)
        except Exception:
            logging.exception("message") #Se envia un meme diciendo que hubo un error
            try:
                if str(tweets[ID][1])!=my_screen_name:
                    replyto="@"+str(tweets[ID][1])
                else:
                    replyto=""
                kwargs={"status":"Error" ,"in_reply_to_status_id":ID}
                api.update_status(**kwargs)
            except Exception:
                logging.exception("message")



#Blob functions credentials
azure_key=""
account_name=""
container_name=''
json_blob_name=""

def _BlobAccess():
    block_blob_service=BlockBlobService(account_name=account_name, account_key=azure_key)
    blobstring=block_blob_service.get_blob_to_text(container_name, json_blob_name).content
    blobjson=json.loads(blobstring)
    return(blobjson)

def _BlobSubmit(newjson):
    jsonstring=json.dumps(newjson, indent=2)
    block_blob_service=BlockBlobService(account_name=account_name, account_key=azure_key)
    block_blob_service.create_blob_from_text(container_name, json_blob_name, jsonstring)
    return None

def clearjson():
    block_blob_service=BlockBlobService(account_name=account_name, account_key=azure_key)
    blobstring=block_blob_service.get_blob_to_text(container_name, json_blob_name).content
    blobjson=json.loads(blobstring)
    AllLists=blobjson["tweetIDs"]
    AllLists=[x for x in AllLists if x!=[]]
    blobjson["tweetIDs"]=AllLists
    print(json.dumps(blobjson, indent=2))
    newjson=json.dumps(blobjson, indent=2)
    block_blob_service.create_blob_from_text(container_name, "logData.json", newjson)
    print("done")

def get_since_id_Blob():
    blobjson=_BlobAccess()
    return blobjson["since_id"]

def saveData_Blob(IDs, since_id, new_since_id):
    print("new_since_id: " + str(new_since_id))
    if new_since_id>since_id:
        blobjson=_BlobAccess()
        blobjson["since_id"]=new_since_id
        blobjson["sinceDate"]=str(datetime.datetime.now())
        blobjson["tweetIDs"].append(IDs)
        _BlobSubmit(blobjson)
        return None

def _gettweetfulltext(status):
    "Elimina ruido del text, por ejemplo enlaces e imagenes"
    indexes=list()
    text=status.full_text
    entities=status.entities
    del entities["user_mentions"] #Las mentions se quedan
    del entities["hashtags"]
    for entity in entities.keys():
        print(entity)
        elements=entities[entity]
        for element in elements:
            elindx=element["indices"]
            indexes.append(elindx)
    strings=list()
    for index in indexes:
        strings.append(text[index[0]:index[1]])
    for string in strings:
        if string in text:
            text=text.replace(string, "", 1)
    return(text)