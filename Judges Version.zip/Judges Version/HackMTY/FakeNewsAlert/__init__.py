import datetime
import logging
import azure.functions as func
import sys
import os
from twitterconnect import *

dir_path = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, dir_path)


def main(mytimer: func.TimerRequest) -> None:
    since_id=1
    #since_id=get_since_id_Blob()
    (tweets, new_since_id)=check_mentions(api, since_id)
    mention_reply(tweets)
    #saveData_Blob(list(tweets.keys()), since_id, new_since_id)


    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)
