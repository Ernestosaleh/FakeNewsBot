import requests
import json

big_str3="the indian embassy in tokyo has said that one more indian crew member on diamond princess has tested positive for covid 19 https www indiatoday in india story third indian aboard japanese ship tests positive for coronavirus 1646514 2020 02 14"

def getfromAPI(tweet_string):
    response=requests.get("http://127.0.0.1:8000/prediccion/"+tweet_string)
    data=json.loads(response.text)
    x=float(data["tweet_string"])
    if x>=0.5:
        y=1
    elif x<0.5:
        y=0
    return(y)

print(getfromAPI(big_str3))